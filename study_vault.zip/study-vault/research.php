<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_student();

$q        = clean_text($_GET['q'] ?? '');
$category = valid_id($_GET['category'] ?? null);
$year     = filter_var($_GET['year'] ?? '', FILTER_VALIDATE_INT, ['options' => ['min_range' => 2022, 'max_range' => 2025]]);

$where  = [];
$params = [];

if ($q !== '') {
    $where[] = '(r.title LIKE :q OR r.keywords LIKE :q2 OR EXISTS(SELECT 1 FROM research_authors ra JOIN authors a ON a.author_id=ra.author_id WHERE ra.research_id=r.research_id AND a.full_name LIKE :q3))';
    $params[':q']  = '%' . $q . '%';
    $params[':q2'] = '%' . $q . '%';
    $params[':q3'] = '%' . $q . '%';
}

if ($category) {
    $where[] = 'r.category_id=:category';
    $params[':category'] = $category;
}

if ($year) {
    $where[] = 'r.year=:year';
    $params[':year'] = $year;
}

$ws = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$base = 'FROM research r JOIN categories c ON c.category_id=r.category_id LEFT JOIN programs p ON p.program_id=r.program_id';

$count = $pdo->prepare('SELECT COUNT(*) ' . $base . ' ' . $ws);
$count->execute($params);
$total = (int) $count->fetchColumn();

$s = $pdo->prepare("
    SELECT
        r.*,
        c.category_name,
        p.program_name,
        (
            SELECT GROUP_CONCAT(a.full_name ORDER BY a.full_name SEPARATOR ', ')
            FROM research_authors ra
            JOIN authors a ON a.author_id = ra.author_id
            WHERE ra.research_id = r.research_id
        ) researchers
    $base
    $ws
    ORDER BY r.published_date DESC, r.research_id DESC
");
$s->execute($params);
$rows = $s->fetchAll();

$cats = get_categories($pdo);

$pageTitle = 'Search Research';
require __DIR__ . '/includes/header.php';
?>

<div class="container section">
    <header class="page-head">
        <p class="eyebrow">RESEARCH REPOSITORY</p>
        <h1>Search Research</h1>
        <p>Search the available 2022–2025 IT research collection.</p>
    </header>

    <form class="filter-panel live-search-form" method="get" autocomplete="off">
        <div class="row g-2">
            <div class="col-12 col-lg-6">
                <label class="form-label">Search</label>
                <div class="suggest-wrap">
                    <input class="form-control live-search" name="q" value="<?= e($q) ?>" placeholder="Research title, researcher, keyword..." data-suggest-url="<?= BASE_URL ?>suggestions.php">
                    <div class="suggestions" hidden></div>
                </div>
            </div>
            <div class="col-6 col-lg-3">
                <label class="form-label">Major</label>
                <select class="form-select" name="category">
                    <option value="">All majors</option>
                    <?php foreach ($cats as $c): ?>
                        <option value="<?= (int) $c['category_id'] ?>" <?= $category === (int) $c['category_id'] ? 'selected' : '' ?>><?= e($c['category_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-6 col-lg-3">
                <label class="form-label">Year</label>
                <select class="form-select" name="year">
                    <option value="">2022–2025</option>
                    <?php for ($y = 2025; $y >= 2022; $y--): ?>
                        <option value="<?= $y ?>" <?= $year === $y ? 'selected' : '' ?>><?= $y ?></option>
                    <?php endfor; ?>
                </select>
            </div>
        </div>

        <div class="filter-actions">
            <span class="result-count mb-0"><?= $total ?> research record<?= $total === 1 ? '' : 's' ?> found.</span>
            <div class="d-flex gap-2">
                <a class="btn btn-outline-secondary" href="<?= BASE_URL ?>research.php">Clear</a>
                <button class="btn btn-primary" type="submit">Search</button>
            </div>
        </div>
    </form>

    <?php if (!$rows): ?>
        <div class="empty-state">
            <h2>No research found.</h2>
            <p>Try another title, researcher, keyword, major, or year.</p>
        </div>
    <?php else: ?>
        <div class="row g-3">
            <?php foreach ($rows as $r): ?>
                <div class="col-md-6 col-lg-4">
                    <article class="research-card">
                        <p class="card-meta"><?= e($r['category_name']) ?> · <?= e($r['year']) ?></p>
                        <h2 class="h5">
                            <a href="<?= BASE_URL ?>research-details.php?id=<?= (int) $r['research_id'] ?>"><?= e($r['title']) ?></a>
                        </h2>
                        <p class="card-authors"><strong>Researchers:</strong> <?= e($r['researchers'] ?? 'Not recorded') ?></p>
                        <p class="card-abstract"><?= e(excerpt($r['abstract'])) ?></p>
                        <p class="card-program"><strong>Published:</strong> <?= e(format_date($r['published_date'])) ?></p>
                        <div class="card-foot">
                            <a class="card-link" href="<?= BASE_URL ?>research-details.php?id=<?= (int) $r['research_id'] ?>">View details →</a>
                            <?php if (research_file_exists($r['file_path'])): ?>
                                <span class="doc-flag">PDF available</span>
                            <?php endif; ?>
                        </div>
                    </article>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>