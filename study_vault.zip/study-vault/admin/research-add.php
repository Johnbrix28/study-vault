<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_admin();

$form = [
    'title'          => '',
    'researchers'    => '',
    'abstract'       => '',
    'year'           => '2025',
    'published_date' => '',
    'keywords'       => '',
    'category_id'    => '',
    'program_id'     => '1',
];

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        $error = 'Session expired. Please try again.';
    } else {
        $form['title']          = clean_text($_POST['title'] ?? '');
        $form['researchers']    = clean_text($_POST['researchers'] ?? '');
        $form['abstract']       = trim($_POST['abstract'] ?? '');
        $form['published_date'] = $_POST['published_date'] ?? '';
        $form['keywords']       = clean_text($_POST['keywords'] ?? '');
        $form['category_id']    = valid_id($_POST['category_id'] ?? null);
        $form['program_id']     = valid_id($_POST['program_id'] ?? null);

        $year = (int) date('Y', strtotime($form['published_date']));

        if (
            $form['title'] === ''
            || $form['researchers'] === ''
            || !$form['category_id']
            || !$form['published_date']
        ) {
            $error = 'Complete the required fields.';
        } elseif ($year < 2022 || $year > 2025) {
            $error = 'Date Published must be within 2022-2025.';
        } else {
            $uploadError = null;
            $file = handle_pdf_upload($_FILES['document'] ?? [], $uploadError);

            if ($file === false) {
                $error = $uploadError;
            } else {
                try {
                    $pdo->beginTransaction();

                    $stmt = $pdo->prepare('INSERT INTO research(title,abstract,year,published_date,keywords,category_id,program_id,file_path) VALUES(?,?,?,?,?,?,?,?)');
                    $stmt->execute([
                        $form['title'],
                        $form['abstract'] ?: null,
                        $year,
                        $form['published_date'],
                        $form['keywords'] ?: null,
                        $form['category_id'],
                        $form['program_id'],
                        $file,
                    ]);

                    $id = (int) $pdo->lastInsertId();
                    sync_researchers($pdo, $id, $form['researchers']);
                    $pdo->commit();

                    log_activity($pdo, 'Uploaded thesis: ' . $form['title']);
                    set_flash('success', 'Research uploaded successfully.');
                    redirect(BASE_URL . 'admin/research-database.php');
                } catch (PDOException $ex) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }

                    delete_research_file($file);
                    $error = 'The research could not be saved.';
                    error_log($ex->getMessage());
                }
            }
        }
    }
}

$cats = get_categories($pdo);
$programs = get_programs($pdo);

$pageTitle = 'Upload Thesis';
require __DIR__ . '/../includes/admin-header.php';
?>

<header class="admin-head">
    <div>
        <h1>Upload Thesis</h1>
        <p>Add an authorized research record and its PDF document.</p>
    </div>
</header>

<section class="panel form-panel">
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" data-validate>
        <?= csrf_field() ?>

        <div class="row g-3">
            <div class="col-lg-8">
                <label class="form-label">Research Title *</label>
                <input class="form-control" name="title" required placeholder="Enter the research title" value="<?= e($form['title']) ?>">

                <label class="form-label mt-3">Researchers *</label>
                <input class="form-control" name="researchers" required placeholder="Juan D. Santos, Maria L. Reyes" value="<?= e($form['researchers']) ?>">

                <label class="form-label mt-3">Abstract</label>
                <textarea class="form-control" name="abstract" rows="9" placeholder="Enter the research abstract"><?= e($form['abstract']) ?></textarea>

                <label class="form-label mt-3">Keywords</label>
                <input class="form-control" name="keywords" placeholder="e.g. web system, repository, information technology" value="<?= e($form['keywords']) ?>">
            </div>

            <div class="col-lg-4">
                <label class="form-label">Category / Major *</label>
                <select class="form-select" name="category_id" required>
                    <option value="">Select major</option>
                    <?php foreach ($cats as $cat): ?>
                        <option value="<?= $cat['category_id'] ?>" <?= $form['category_id'] == $cat['category_id'] ? 'selected' : '' ?>><?= e($cat['category_name']) ?></option>
                    <?php endforeach; ?>
                </select>

                <label class="form-label mt-3">Date Published *</label>
                <input class="form-control" type="date" name="published_date" min="2022-01-01" max="2025-12-31" required value="<?= e($form['published_date']) ?>">

                <label class="form-label mt-3">Program</label>
                <select class="form-select" name="program_id">
                    <?php foreach ($programs as $program): ?>
                        <option value="<?= $program['program_id'] ?>" <?= $form['program_id'] == $program['program_id'] ? 'selected' : '' ?>><?= e($program['program_name']) ?></option>
                    <?php endforeach; ?>
                </select>

                <label class="form-label mt-3">Research PDF</label>
                <input class="form-control" type="file" name="document" accept="application/pdf">
                <small class="form-text">PDF only, up to <?= MAX_UPLOAD_BYTES / 1048576 ?> MB.</small>
            </div>
        </div>

        <div class="form-actions">
            <a class="btn btn-outline-secondary" href="<?= BASE_URL ?>admin/research-database.php">Cancel</a>
            <button class="btn btn-primary">Upload Thesis</button>
        </div>
    </form>
</section>

<?php require __DIR__ . '/../includes/admin-footer.php'; ?>