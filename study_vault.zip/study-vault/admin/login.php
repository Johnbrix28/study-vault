<?php
/**
 * Administrator sign-in.
 */
require_once __DIR__ . '/../includes/bootstrap.php';

if (is_logged_in()) {
    redirect(BASE_URL . 'admin/dashboard.php');
}

$error    = '';
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        $error = 'Your session expired. Try signing in again.';
    } else {
        $username = clean_text($_POST['username'] ?? '');
        $password = (string) ($_POST['password'] ?? '');

        if ($username === '' || $password === '') {
            $error = 'Enter both your username and password.';
        } else {
            try {
                $stmt = $pdo->prepare('SELECT * FROM administrators WHERE username = ? LIMIT 1');
                $stmt->execute([$username]);
                $admin = $stmt->fetch();

                if ($admin && password_verify($password, $admin['password'])) {
                    login_admin($admin);
                    log_activity($pdo, 'Signed in');
                    set_flash('success', 'Signed in as ' . $admin['name'] . '.');
                    redirect(BASE_URL . 'admin/dashboard.php');
                }
                // Same message for unknown user and wrong password.
                $error = 'Invalid username or password.';
            } catch (PDOException $ex) {
                error_log('Admin login failed: ' . $ex->getMessage());
                $error = 'Sign-in is unavailable right now. Try again in a moment.';
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Administrator login &middot; <?= e(SITE_NAME) ?></title>
<link rel="icon" href="<?= BASE_URL ?>assets/images/study-vault-logo.png">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="<?= BASE_URL ?>assets/css/style.css" rel="stylesheet">
</head>
<body class="auth-page">
<div class="auth-overlay">
  <div class="auth-card">
    <div class="login-brand">
      <img src="<?= BASE_URL ?>assets/images/isu-logo.png" alt="" onerror="this.style.display='none'">
      <div>
        <strong><?= e(SITE_NAME) ?></strong>
        <span><?= e(SITE_TAGLINE) ?></span>
      </div>
    </div>

    <h1>Administrator login</h1>
    <p class="login-sub">Authorized library personnel only. Student users should use the Student Login.</p>

    <?php render_flashes(); ?>

    <?php if ($error): ?>
      <div class="alert alert-danger" role="alert"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="post" action="<?= BASE_URL ?>admin/login.php" novalidate>
      <?= csrf_field() ?>
      <div class="mb-3">
        <label class="form-label" for="username">Username</label>
        <input class="form-control" type="text" id="username" name="username" required autofocus
               autocomplete="username" value="<?= e($username) ?>">
      </div>
      <div class="mb-3">
        <label class="form-label" for="password">Password</label>
        <input class="form-control" type="password" id="password" name="password" required autocomplete="current-password">
      </div>
      <button class="btn btn-primary w-100" type="submit">Sign in</button>
    </form>

    <a class="login-back" href="<?= BASE_URL ?>login.php">Student Login</a><a class="login-back" href="<?= BASE_URL ?>index.php">&larr; Back to the repository</a>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
