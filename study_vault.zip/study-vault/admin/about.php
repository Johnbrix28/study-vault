<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_student();

$pageTitle = 'About';
require __DIR__ . '/includes/header.php';
?>

<div class="container section">
    <header class="page-head">
        <p class="eyebrow">STUDY VAULT</p>
        <h1>About the System</h1>
        <p>A research repository for Information Technology students.</p>
    </header>

    <div class="feature-card about-card">
        <div class="prose">
            <h2>Purpose</h2>
            <p>Study Vault provides one searchable place for authorized thesis and research works from 2022–2025 so IT students can discover related studies and research references.</p>

            <h2>Student access</h2>
            <p>Students can search, filter, browse research details, read abstracts, and view an available PDF directly beside the abstract.</p>

            <h2>Administrator access</h2>
            <p>Authorized library personnel can upload, view, edit, replace PDF files, and delete research records. Administrators can also view registered students, categories, and activity logs.</p>

            <h2>Research categories</h2>
            <p>The repository focuses on two IT major areas: <strong>Web and Mobile Application Development</strong> and <strong>Networking Security</strong>.</p>
        </div>
    </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>