<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_admin();

$q = clean_text($_GET['q'] ?? '');

$params = [];
$where  = '';

if ($q !== '') {
    $where = 'WHERE student_number LIKE :q OR first_name LIKE :q2 OR last_name LIKE :q3 OR CONCAT(first_name, " ", last_name) LIKE :q4';
    $params = [
        ':q'  => "%$q%",
        ':q2' => "%$q%",
        ':q3' => "%$q%",
        ':q4' => "%$q%",
    ];
}

$stmt = $pdo->prepare('SELECT * FROM students ' . $where . ' ORDER BY created_at DESC');
$stmt->execute($params);
$students = $stmt->fetchAll();

$pageTitle = 'Students';
require __DIR__ . '/../includes/admin-header.php';
?>

<header class="admin-head">
    <div>
        <h1>Students</h1>
        <p>Registered student accounts.</p>
    </div>
</header>

<form class="panel filter-inline" method="get">
    <div class="row g-2">
        <div class="col-md-9">
            <label class="form-label">Search Student ID, ID number, or name</label>
            <input class="form-control" name="q" value="<?= e($q) ?>" placeholder="Search students...">
        </div>
        <div class="col-md-3 d-grid">
            <button class="btn btn-primary align-self-end">Search</button>
        </div>
    </div>
</form>

<section class="panel">
    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Date Registered</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($students as $i => $student): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td><?= e($student['student_number']) ?></td>
                        <td><?= e($student['first_name'] . ' ' . $student['last_name']) ?></td>
                        <td><?= e(format_date($student['created_at'])) ?></td>
                        <td>
                            <form method="post" action="<?= BASE_URL ?>admin/student-delete.php" onsubmit="return confirm('Delete this student account?');">
                                <input type="hidden" name="student_id" value="<?= (int) $student['student_id'] ?>">
                                <?= csrf_field() ?>
                                <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php if (!$students): ?>
            <p class="empty-note">No students found.</p>
        <?php endif; ?>
    </div>
</section>

<?php require __DIR__ . '/../includes/admin-footer.php'; ?>