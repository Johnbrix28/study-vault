<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_admin();

$stats = [
    'research'   => (int) $pdo->query('SELECT COUNT(*) FROM research')->fetchColumn(),
    'categories' => (int) $pdo->query('SELECT COUNT(*) FROM categories')->fetchColumn(),
    'students'   => (int) $pdo->query('SELECT COUNT(*) FROM students')->fetchColumn(),
];

$recent = $pdo->query("
    SELECT
        r.research_id,
        r.title,
        r.published_date,
        c.category_name,
        (
            SELECT GROUP_CONCAT(a.full_name ORDER BY a.full_name SEPARATOR ', ')
            FROM research_authors ra
            JOIN authors a ON a.author_id = ra.author_id
            WHERE ra.research_id = r.research_id
        ) researchers
    FROM research r
    JOIN categories c ON c.category_id = r.category_id
    ORDER BY r.published_date DESC, r.research_id DESC
    LIMIT 8
")->fetchAll();

$pageTitle = 'Dashboard';
require __DIR__ . '/../includes/admin-header.php';
?>

<header class="admin-head">
    <div>
        <h1>Dashboard</h1>
        <p>Manage the Study Vault repository and monitor recent uploads.</p>
    </div>
    <a class="btn btn-primary" href="<?= BASE_URL ?>admin/research-add.php">Upload Thesis</a>
</header>

<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="stat-card">
            <p class="stat-label">Total Research Projects</p>
            <p class="stat-value"><?= $stats['research'] ?></p>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card">
            <p class="stat-label">Total Categories</p>
            <p class="stat-value"><?= $stats['categories'] ?></p>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card">
            <p class="stat-label">Registered Students</p>
            <p class="stat-value"><?= $stats['students'] ?></p>
        </div>
    </div>
</div>

<section class="panel">
    <div class="panel-head">
        <h2 class="panel-title">Recent Uploads</h2>
        <a href="<?= BASE_URL ?>admin/research-database.php">Research Database</a>
    </div>
    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Researchers</th>
                    <th>Category</th>
                    <th>Date Published</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recent as $r): ?>
                    <tr>
                        <td><?= e($r['title']) ?></td>
                        <td><?= e($r['researchers'] ?? '--') ?></td>
                        <td><?= e($r['category_name']) ?></td>
                        <td><?= e(format_date($r['published_date'])) ?></td>
                        <td>
                            <a class="btn btn-sm btn-outline-primary" href="<?= BASE_URL ?>research-details.php?id=<?= (int) $r['research_id'] ?>">View</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php if (!$recent): ?>
            <p class="empty-note">No research uploads yet.</p>
        <?php endif; ?>
    </div>
</section>

<?php require __DIR__ . '/../includes/admin-footer.php'; ?>