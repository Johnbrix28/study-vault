<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_admin();

$id = valid_id($_POST['student_id'] ?? null);
if (!$id || !csrf_valid()) {
    set_flash('danger', 'The student could not be deleted. Please try again.');
    redirect(BASE_URL . 'admin/students.php');
}

try {
    $stmt = $pdo->prepare('DELETE FROM students WHERE student_id = ?');
    $stmt->execute([$id]);
    $deleted = $stmt->rowCount() === 1;
    set_flash($deleted ? 'success' : 'warning', $deleted ? 'Student account deleted.' : 'Student account was not found.');
} catch (PDOException $ex) {
    error_log('Delete student failed: ' . $ex->getMessage());
    set_flash('danger', 'The student account could not be deleted.');
}

redirect(BASE_URL . 'admin/students.php');
