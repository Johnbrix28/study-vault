<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_admin();

$id = valid_id($_GET['id'] ?? null);
if (!$id) {
    redirect(BASE_URL . 'admin/research-database.php');
}

$s = $pdo->prepare('SELECT * FROM research WHERE research_id=?');
$s->execute([$id]);
$record = $s->fetch();

if (!$record) {
    set_flash('warning', 'Research record not found.');
    redirect(BASE_URL . 'admin/research-database.php');
}

$form = [
    'title'          => $record['title'],
    'researchers'    => implode(', ', get_research_authors($pdo, $id)),
    'abstract'       => $record['abstract'] ?? '',
    'keywords'       => $record['keywords'] ?? '',
    'category_id'    => $record['category_id'],
    'program_id'     => $record['program_id'],
    'published_date' => $record['published_date'],
];

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        $error = 'Session expired. Please try again.';
    } else {
        $form['title']          = clean_text($_POST['title'] ?? '');
        $form['researchers']    = clean_text($_POST['researchers'] ?? '');
        $form['abstract']       = trim($_POST['abstract'] ?? '');
        $form['keywords']       = clean_text($_POST['keywords'] ?? '');
        $form['category_id']    = valid_id($_POST['category_id'] ?? null);
        $form['program_id']     = valid_id($_POST['program_id'] ?? null);
        $form['published_date'] = $_POST['published_date'] ?? '';

        $year = (int) date('Y', strtotime($form['published_date']));

        if (
            !$form['title']
            || !$form['researchers']
            || !$form['category_id']
            || !$form['published_date']
        ) {
            $error = 'Complete the required fields.';
        } elseif ($year < 2022 || $year > 2025) {
            $error = 'Date Published must be within 2022–2025.';
        } else {
            $uploadError = null;
            $newFile = handle_pdf_upload($_FILES['document'] ?? [], $uploadError);

            if ($newFile === false) {
                $error = $uploadError;
            } else {
                try {
                    $pdo->beginTransaction();

                    $path = $newFile ?: $record['file_path'];

                    if (!empty($_POST['remove_file'])) {
                        $path = null;
                    }

                    $u = $pdo->prepare('UPDATE research SET title=?,abstract=?,year=?,published_date=?,keywords=?,category_id=?,program_id=?,file_path=? WHERE research_id=?');
                    $u->execute([
                        $form['title'],
                        $form['abstract'] ?: null,
                        $year,
                        $form['published_date'],
                        $form['keywords'] ?: null,
                        $form['category_id'],
                        $form['program_id'],
                        $path,
                        $id,
                    ]);

                    sync_researchers($pdo, $id, $form['researchers']);
                    $pdo->commit();

                    if ($record['file_path'] && $record['file_path'] !== $path) {
                        delete_research_file($record['file_path']);
                    }

                    log_activity($pdo, 'Edited research: ' . $form['title']);
                    set_flash('success', 'Research record updated.');
                    redirect(BASE_URL . 'admin/research-database.php');
                } catch (PDOException $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }

                    delete_research_file($newFile);
                    $error = 'The changes could not be saved.';
                    error_log($e->getMessage());
                }
            }
        }
    }
}

$cats = get_categories($pdo);
$programs = get_programs($pdo);

$pageTitle = 'Edit Research';
require __DIR__ . '/../includes/admin-header.php';
?>

<header class="admin-head">
    <div>
        <p class="eyebrow">RESEARCH DATABASE</p>
        <h1>Edit Research</h1>
        <p>Update metadata or replace the research PDF.</p>
    </div>
    <div class="d-flex gap-2">
        <a class="btn btn-outline-secondary" href="<?= BASE_URL ?>research-details.php?id=<?= $id ?>">View</a>
        <a class="btn btn-outline-danger" href="<?= BASE_URL ?>admin/research-delete.php?id=<?= $id ?>">Delete</a>
    </div>
</header>

<section class="panel form-panel">
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" data-validate>
        <?= csrf_field() ?>

        <div class="row g-3">
            <div class="col-lg-8">
                <label class="form-label">Research Title *</label>
                <input class="form-control" name="title" required value="<?= e($form['title']) ?>">

                <label class="form-label mt-3">Researchers *</label>
                <input class="form-control" name="researchers" required value="<?= e($form['researchers']) ?>">

                <label class="form-label mt-3">Abstract</label>
                <textarea class="form-control" name="abstract" rows="10"><?= e($form['abstract']) ?></textarea>

                <label class="form-label mt-3">Keywords</label>
                <input class="form-control" name="keywords" value="<?= e($form['keywords']) ?>">
            </div>

            <div class="col-lg-4">
                <label class="form-label">Category / Major *</label>
                <select class="form-select" name="category_id" required>
                    <?php foreach ($cats as $c): ?>
                        <option value="<?= $c['category_id'] ?>" <?= $form['category_id'] == $c['category_id'] ? 'selected' : '' ?>><?= e($c['category_name']) ?></option>
                    <?php endforeach; ?>
                </select>

                <label class="form-label mt-3">Date Published *</label>
                <input class="form-control" type="date" name="published_date" min="2022-01-01" max="2025-12-31" required value="<?= e($form['published_date']) ?>">

                <label class="form-label mt-3">Program</label>
                <select class="form-select" name="program_id">
                    <?php foreach ($programs as $p): ?>
                        <option value="<?= $p['program_id'] ?>" <?= $form['program_id'] == $p['program_id'] ? 'selected' : '' ?>><?= e($p['program_name']) ?></option>
                    <?php endforeach; ?>
                </select>

                <div class="mt-3">
                    <label class="form-label">Research PDF</label>

                    <?php if (research_file_exists($record['file_path'])): ?>
                        <a class="btn btn-sm btn-outline-primary d-block mb-2" href="<?= BASE_URL . e($record['file_path']) ?>" target="_blank">Open Current PDF</a>
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" name="remove_file" value="1" id="remove">
                            <label class="form-check-label" for="remove">Remove current PDF</label>
                        </div>
                    <?php endif; ?>

                    <input class="form-control" type="file" name="document" accept="application/pdf">
                    <small class="form-text">Upload a new PDF to replace the current one.</small>
                </div>
            </div>
        </div>

        <div class="form-actions">
            <a class="btn btn-outline-secondary" href="<?= BASE_URL ?>admin/research-database.php">Cancel</a>
            <button class="btn btn-primary">Save Changes</button>
        </div>
    </form>
</section>

<?php require __DIR__ . '/../includes/admin-footer.php'; ?>