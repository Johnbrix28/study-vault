<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_admin();

$cats = $pdo->query("
    SELECT
        c.category_id,
        c.category_name,
        c.description,
        COUNT(r.research_id) total
    FROM categories c
    LEFT JOIN research r ON r.category_id = c.category_id
    GROUP BY c.category_id, c.category_name, c.description
    ORDER BY c.category_id
")->fetchAll();

$pageTitle = 'Category Display';
require __DIR__ . '/../includes/admin-header.php';
?>

<header class="admin-head">
    <div>
        <h1>Category Display</h1>
        <p>Study Vault focuses on the two IT major categories below.</p>
    </div>
</header>

<div class="row g-3">
    <?php foreach ($cats as $c): ?>
        <div class="col-lg-6">
            <section class="panel category-major">
                <h2><?= e($c['category_name']) ?></h2>
                <p><?= e($c['description']) ?></p>
                <strong><?= $c['total'] ?> research record<?= ((int) $c['total'] === 1 ? '' : 's') ?></strong>
                <hr>

                <?php
                $s = $pdo->prepare('SELECT research_id,title,year FROM research WHERE category_id=? ORDER BY published_date DESC');
                $s->execute([$c['category_id']]);
                $rs = $s->fetchAll();
                ?>

                <ul class="major-list">
                    <?php foreach ($rs as $r): ?>
                        <li>
                            <a href="<?= BASE_URL ?>research-details.php?id=<?= (int) $r['research_id'] ?>"><?= e($r['title']) ?></a>
                            <span><?= $r['year'] ?></span>
                        </li>
                    <?php endforeach; ?>

                    <?php if (!$rs): ?>
                        <li class="text-muted">No research records yet.</li>
                    <?php endif; ?>
                </ul>
            </section>
        </div>
    <?php endforeach; ?>
</div>

<?php require __DIR__ . '/../includes/admin-footer.php'; ?>