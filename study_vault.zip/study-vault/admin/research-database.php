<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_admin();

$q        = clean_text($_GET['q'] ?? '');
$category = valid_id($_GET['category'] ?? null);

$params = [];
$where  = [];

if ($q !== '') {
    $where[] = '(r.title LIKE :q OR EXISTS(SELECT 1 FROM research_authors ra JOIN authors a ON a.author_id=ra.author_id WHERE ra.research_id=r.research_id AND a.full_name LIKE :q2) OR c.category_name LIKE :q3)';
    $params[':q']  = '%' . $q . '%';
    $params[':q2'] = '%' . $q . '%';
    $params[':q3'] = '%' . $q . '%';
}

if ($category) {
    $where[] = 'r.category_id=:cat';
    $params[':cat'] = $category;
}

$ws = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$s = $pdo->prepare("
    SELECT
        r.*,
        c.category_name,
        (
            SELECT GROUP_CONCAT(a.full_name ORDER BY a.full_name SEPARATOR ', ')
            FROM research_authors ra
            JOIN authors a ON a.author_id = ra.author_id
            WHERE ra.research_id = r.research_id
        ) researchers
    FROM research r
    JOIN categories c ON c.category_id = r.category_id
    $ws
    ORDER BY r.published_date DESC, r.research_id DESC
");
$s->execute($params);
$rows = $s->fetchAll();

$cats = get_categories($pdo);

$pageTitle = 'Research Database';
require __DIR__ . '/../includes/admin-header.php';
?>

<header class="admin-head">
    <div>
        <h1>Research Database</h1>
        <p>Store and manage authorized IT research records from 2022–2025.</p>
    </div>
    <a class="btn btn-primary" href="<?= BASE_URL ?>admin/research-add.php">Upload Thesis</a>
</header>

<form class="panel filter-inline" method="get">
    <div class="row g-2">
        <div class="col-md-7">
            <label class="form-label">Search title or researcher</label>
            <input class="form-control" name="q" value="<?= e($q) ?>">
        </div>
        <div class="col-md-3">
            <label class="form-label">Category</label>
            <select class="form-select" name="category">
                <option value="">All majors</option>
                <?php foreach ($cats as $c): ?>
                    <option value="<?= $c['category_id'] ?>" <?= $category === $c['category_id'] ? 'selected' : '' ?>><?= e($c['category_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-2 d-grid">
            <button class="btn btn-primary align-self-end">Search</button>
        </div>
    </div>
</form>

<section class="panel">
    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Researchers</th>
                    <th>Category</th>
                    <th>Date Published</th>
                    <th class="text-end">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td><?= e($r['title']) ?></td>
                        <td><?= e($r['researchers'] ?? '--') ?></td>
                        <td><?= e($r['category_name']) ?></td>
                        <td><?= e(format_date($r['published_date'])) ?></td>
                        <td class="text-end text-nowrap">
                            <a class="btn btn-sm btn-outline-secondary" href="<?= BASE_URL ?>research-details.php?id=<?= $r['research_id'] ?>">View</a>
                            <a class="btn btn-sm btn-outline-primary" href="<?= BASE_URL ?>admin/research-edit.php?id=<?= $r['research_id'] ?>">Edit</a>
                            <a class="btn btn-sm btn-outline-danger" href="<?= BASE_URL ?>admin/research-delete.php?id=<?= $r['research_id'] ?>">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php if (!$rows): ?>
            <p class="empty-note">No research records found.</p>
        <?php endif; ?>
    </div>
</section>

<?php require __DIR__ . '/../includes/admin-footer.php'; ?>