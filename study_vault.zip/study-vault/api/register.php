<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once __DIR__ . '/../config/database.php';

$number = trim($_POST['student_number'] ?? '');
$firstName = trim($_POST['first_name'] ?? '');
$lastName = trim($_POST['last_name'] ?? '');
$password = (string)($_POST['password'] ?? '');

if ($number === '' || $firstName === '' || $lastName === '' || $password === '') {
    echo json_encode(['success' => false, 'message' => 'Complete all fields']);
    exit;
}

if (strlen($password) < 6) {
    echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters']);
    exit;
}

$stmt = $pdo->prepare('SELECT student_id FROM students WHERE student_number = ?');
$stmt->execute([$number]);
if ($stmt->fetch()) {
    echo json_encode(['success' => false, 'message' => 'Student ID already registered']);
    exit;
}

$stmt = $pdo->prepare('INSERT INTO students (student_number, first_name, last_name, password) VALUES (?, ?, ?, ?)');
$stmt->execute([$number, $firstName, $lastName, password_hash($password, PASSWORD_DEFAULT)]);

echo json_encode(['success' => true, 'message' => 'Account created']);