<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once __DIR__ . '/../config/database.php';

$q        = trim($_GET['q'] ?? '');
$category = $_GET['category'] ?? null;
$year     = $_GET['year'] ?? null;

$where  = [];
$params = [];

if ($q !== '') {
    $where[] = '(r.title LIKE :q1 
                 OR r.keywords LIKE :q2 
                 OR c.category_name LIKE :q3
                 OR EXISTS(
                     SELECT 1 FROM research_authors ra
                     JOIN authors a ON a.author_id = ra.author_id
                     WHERE ra.research_id = r.research_id
                     AND a.full_name LIKE :q4
                 ))';
    $params[':q1'] = "%$q%";
    $params[':q2'] = "%$q%";
    $params[':q3'] = "%$q%";
    $params[':q4'] = "%$q%";
}

if ($category) {
    $where[] = 'r.category_id = :cat';
    $params[':cat'] = $category;
}

if ($year) {
    $where[] = 'r.year = :yr';
    $params[':yr'] = $year;
}

$ws = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$sql = "SELECT 
            r.research_id, 
            r.title, 
            r.abstract, 
            r.year, 
            r.published_date,
            r.keywords, 
            r.file_path, 
            c.category_id,
            c.category_name,
            (SELECT GROUP_CONCAT(a.full_name ORDER BY a.full_name SEPARATOR ', ')
                FROM research_authors ra
                JOIN authors a ON a.author_id = ra.author_id
                WHERE ra.research_id = r.research_id) AS researchers
        FROM research r
        JOIN categories c ON c.category_id = r.category_id
        $ws
        ORDER BY r.published_date DESC, r.research_id DESC
        LIMIT 50";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(['success' => true, 'data' => $rows]);