<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once __DIR__ . '/../config/database.php';

$studentNumber = trim($_POST['student_number'] ?? '');
$password = (string)($_POST['password'] ?? '');

if ($studentNumber === '' || $password === '') {
    echo json_encode(['success' => false, 'message' => 'Missing credentials']);
    exit;
}

$stmt = $pdo->prepare('SELECT * FROM students WHERE student_number = ? LIMIT 1');
$stmt->execute([$studentNumber]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if ($student && password_verify($password, $student['password'])) {
    echo json_encode([
        'success' => true,
        'message' => 'Login successful',
        'data' => [
            'student_id'     => (int)$student['student_id'],
            'student_number' => $student['student_number'],
            'first_name'     => $student['first_name'],
            'last_name'      => $student['last_name'],
            'name'           => $student['first_name'] . ' ' . $student['last_name']
        ]
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid Student ID or password']);
}