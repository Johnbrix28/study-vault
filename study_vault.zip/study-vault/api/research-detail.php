<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once __DIR__ . '/../config/database.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) {
    echo json_encode(['success' => false, 'message' => 'Missing ID']);
    exit;
}

// Main research record
$stmt = $pdo->prepare("
    SELECT r.*, c.category_name,
           (SELECT GROUP_CONCAT(a.full_name ORDER BY a.full_name SEPARATOR ', ')
              FROM research_authors ra
              JOIN authors a ON a.author_id = ra.author_id
             WHERE ra.research_id = r.research_id) AS researchers
      FROM research r
      JOIN categories c ON c.category_id = r.category_id
     WHERE r.research_id = ?
     LIMIT 1
");
$stmt->execute([$id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    echo json_encode(['success' => false, 'message' => 'Not found']);
    exit;
}

// ⭐ Related research (same category, excluding current)
$relStmt = $pdo->prepare("
    SELECT r.research_id, r.title, r.year, c.category_name
      FROM research r
      JOIN categories c ON c.category_id = r.category_id
     WHERE r.category_id = ? AND r.research_id <> ?
     ORDER BY r.published_date DESC
     LIMIT 3
");
$relStmt->execute([$row['category_id'], $id]);
$related = $relStmt->fetchAll(PDO::FETCH_ASSOC);

$row['related'] = $related;

echo json_encode(['success' => true, 'data' => $row]);