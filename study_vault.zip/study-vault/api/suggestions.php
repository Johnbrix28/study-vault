<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/../config/database.php';

$q = trim($_GET['q'] ?? '');
if (mb_strlen($q) < 2) { echo json_encode([]); exit; }

$like = "%$q%";
$stmt = $pdo->prepare("SELECT DISTINCT suggestion FROM (
    SELECT title AS suggestion FROM research WHERE title LIKE :q1
    UNION
    SELECT full_name FROM authors WHERE full_name LIKE :q2
    UNION
    SELECT category_name FROM categories WHERE category_name LIKE :q3
) s WHERE suggestion IS NOT NULL AND suggestion <> '' LIMIT 8");
$stmt->execute([':q1' => $like, ':q2' => $like, ':q3' => $like]);

echo json_encode($stmt->fetchAll(PDO::FETCH_COLUMN));