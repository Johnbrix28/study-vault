<?php
require_once __DIR__ . '/includes/bootstrap.php';

if (is_student_logged_in()) {
    redirect(BASE_URL . 'index.php');
}

$error = '';
$studentNumber = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        $error = 'Your session expired. Please try again.';
    } else {
        $studentNumber = clean_text($_POST['student_number'] ?? '');
        $password = (string) ($_POST['password'] ?? '');

        if ($studentNumber === '' || $password === '') {
            $error = 'Enter your Student ID and password.';
        } else {
            $s = $pdo->prepare('SELECT * FROM students WHERE student_number=? LIMIT 1');
            $s->execute([$studentNumber]);
            $student = $s->fetch();

            if ($student && password_verify($password, $student['password'])) {
                login_student($student);
                set_flash('success', 'Welcome to Study Vault, ' . $student['first_name'] . '!');
                redirect(BASE_URL . 'index.php');
            }

            $error = 'Invalid Student ID or password.';
        }
    }
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Student Login &middot; Study Vault</title>
    <link rel="icon" href="<?= BASE_URL ?>assets/images/study-vault-logo.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= BASE_URL ?>assets/css/style.css" rel="stylesheet">
</head>

<body class="auth-page">
    <div class="auth-overlay">
        <div class="auth-card">
            <div class="login-brand">
                <img src="<?= BASE_URL ?>assets/images/isu-logo.png" alt="Study Vault">
                <div>
                    <strong>Study Vault</strong>
                    <span>Thesis and Research System</span>
                </div>
            </div>

            <h1>Student Login</h1>
            <p class="login-sub">Sign in to search and explore the Study Vault research repository.</p>

            <?php render_flashes(); ?>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= e($error) ?></div>
            <?php endif; ?>

            <form method="post" data-validate>
                <?= csrf_field() ?>

                <div class="mb-3">
                    <label class="form-label" for="student_number">Student ID</label>
                    <input class="form-control" id="student_number" name="student_number" required autocomplete="username" value="<?= e($studentNumber) ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label" for="password">Password</label>
                    <input class="form-control" type="password" id="password" name="password" required autocomplete="current-password">
                </div>

                <button class="btn btn-primary w-100" type="submit">Login</button>
            </form>

            <p class="auth-switch">No account yet? <a href="<?= BASE_URL ?>register.php">Create Account</a></p>
            <a class="login-back" href="<?= BASE_URL ?>admin/login.php">Administrator login</a>
        </div>
    </div>
</body>

</html>