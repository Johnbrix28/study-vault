CREATE DATABASE IF NOT EXISTS study_vault CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE study_vault;
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS research_authors, activity_logs, research, authors, categories, programs, students, administrators;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE administrators (
  admin_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role VARCHAR(30) NOT NULL DEFAULT 'admin',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE students (
  student_id INT AUTO_INCREMENT PRIMARY KEY,
  student_number VARCHAR(50) NOT NULL UNIQUE,
  first_name VARCHAR(80) NOT NULL,
  last_name VARCHAR(80) NOT NULL,
  password VARCHAR(255) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_student_number(student_number),
  INDEX idx_student_name(last_name, first_name)
) ENGINE=InnoDB;

CREATE TABLE categories (
  category_id INT AUTO_INCREMENT PRIMARY KEY,
  category_name VARCHAR(120) NOT NULL UNIQUE,
  description VARCHAR(255) DEFAULT NULL
) ENGINE=InnoDB;

CREATE TABLE programs (
  program_id INT AUTO_INCREMENT PRIMARY KEY,
  program_name VARCHAR(150) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE authors (
  author_id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(180) NOT NULL UNIQUE,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE research (
  research_id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  abstract TEXT,
  year SMALLINT NOT NULL,
  published_date DATE NOT NULL,
  keywords VARCHAR(500) DEFAULT NULL,
  category_id INT NOT NULL,
  program_id INT DEFAULT NULL,
  file_path VARCHAR(255) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_title(title), INDEX idx_year(year), INDEX idx_published(published_date), INDEX idx_category(category_id),
  CONSTRAINT fk_research_category FOREIGN KEY(category_id) REFERENCES categories(category_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_research_program FOREIGN KEY(program_id) REFERENCES programs(program_id) ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE research_authors (
  research_id INT NOT NULL,
  author_id INT NOT NULL,
  PRIMARY KEY(research_id,author_id),
  CONSTRAINT fk_ra_research FOREIGN KEY(research_id) REFERENCES research(research_id) ON DELETE CASCADE,
  CONSTRAINT fk_ra_author FOREIGN KEY(author_id) REFERENCES authors(author_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE activity_logs (
  log_id INT AUTO_INCREMENT PRIMARY KEY,
  admin_id INT DEFAULT NULL,
  action VARCHAR(255) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_log_date(created_at),
  CONSTRAINT fk_log_admin FOREIGN KEY(admin_id) REFERENCES administrators(admin_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Development account: admin / admin123
INSERT INTO administrators(name,username,password,role) VALUES
('Development Administrator','admin','$2y$10$jQQ1EJrvsr.Z4a1QJMB2M.YWMa/qE1YbrtLn1CTQECiqiaU/YChai','admin');

INSERT INTO categories(category_name,description) VALUES
('Web and Mobile Application Development','Research related to web systems, mobile applications and application development.'),
('Networking Security','Research related to networking, network administration, cybersecurity and security.' );

INSERT INTO programs(program_name) VALUES ('Bachelor of Science in Information Technology');

-- Clearly fictional development data only. Replace with authorized 2022-2025 records.
INSERT INTO authors(full_name) VALUES ('Sample Researcher A'),('Sample Researcher B'),('Sample Researcher C');
INSERT INTO research(title,abstract,year,published_date,keywords,category_id,program_id) VALUES
('Sample Web-Based Research Repository','This study presents the design and development of a web-based research repository for organizing, searching, and accessing approved academic studies. The proposed system centralizes research records, author information, categories, keywords, publication dates, and document files in one platform. It provides students with a searchable interface for discovering related studies and viewing available research documents, while authorized administrators can manage records and monitor repository activity. The system aims to improve access to references, reduce manual searching, and support a more organized research workflow. Functional testing indicates that the repository can provide a practical and accessible solution for storing and retrieving Information Technology research materials.',2025,'2025-04-15','repository, web, research',1,1),
('Sample Mobile Student Companion','[SAMPLE DATA - DEVELOPMENT ONLY] Fictional record used to test Study Vault.',2024,'2024-08-20','mobile, student, application',1,1),
('Sample Network Access Security Study','[SAMPLE DATA - DEVELOPMENT ONLY] Fictional record used to test Study Vault.',2023,'2023-11-10','networking, security, access',2,1);
INSERT INTO research_authors VALUES (1,1),(1,2),(2,2),(3,3);
INSERT INTO activity_logs(admin_id,action) VALUES (1,'Initial database setup completed');
