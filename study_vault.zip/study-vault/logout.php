<?php
require_once __DIR__ . '/includes/bootstrap.php';

logout_student();
set_flash('success', 'You have been logged out.');
redirect(BASE_URL . 'login.php');