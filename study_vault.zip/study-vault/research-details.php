<?php
require_once __DIR__ . '/includes/bootstrap.php';

$isAdmin = is_logged_in();

if (!$isAdmin && !is_student_logged_in()) {
    set_flash('warning', 'Please sign in to access the research details.');
    redirect(BASE_URL . 'login.php');
}

$id = valid_id($_GET['id'] ?? null);
if (!$id) {
    redirect(BASE_URL . ($isAdmin ? 'admin/research-database.php' : 'research.php'));
}

$stmt = $pdo->prepare('SELECT r.*, c.category_name, p.program_name FROM research r JOIN categories c ON c.category_id = r.category_id LEFT JOIN programs p ON p.program_id = r.program_id WHERE r.research_id = ?');
$stmt->execute([$id]);
$record = $stmt->fetch();

if (!$record) {
    set_flash('warning', 'Research record not found.');
    redirect(BASE_URL . ($isAdmin ? 'admin/research-database.php' : 'research.php'));
}

$authors = get_research_authors($pdo, $id);
$hasFile = research_file_exists($record['file_path']);
$documentUrl = BASE_URL . ltrim((string) $record['file_path'], '/');

$relatedStmt = $pdo->prepare('SELECT research_id, title, year FROM research WHERE category_id = ? AND research_id <> ? ORDER BY published_date DESC LIMIT 4');
$relatedStmt->execute([$record['category_id'], $id]);
$related = $relatedStmt->fetchAll();

$pageTitle = $record['title'];
require __DIR__ . '/includes/header.php';
?>

<div class="container section">
    <a class="back-link" href="<?= BASE_URL . ($isAdmin ? 'admin/research-database.php' : 'research.php') ?>">&larr; Back to research</a>

    <article class="record">
        <div class="record-layout">
            <section class="record-main">
                <p class="record-meta"><?= e($record['category_name']) ?> &middot; <?= e($record['year']) ?></p>
                <h1 class="record-title"><?= e($record['title']) ?></h1>
                <p class="record-authors"><strong>Researchers:</strong> <?= e($authors ? implode(', ', $authors) : 'Not recorded') ?></p>
                <p class="record-published"><strong>Date Published:</strong> <?= e(format_date($record['published_date'])) ?></p>

                <h2 class="record-heading">Abstract</h2>
                <div class="record-abstract">
                    <?= trim((string) $record['abstract']) !== '' ? nl2br(e($record['abstract'])) : '<p class="text-muted">No abstract was recorded.</p>' ?>
                </div>

                <?php if ($tags = keyword_list($record['keywords'])): ?>
                    <h2 class="record-heading">Keywords</h2>
                    <ul class="tag-list tag-list-lg">
                        <?php foreach ($tags as $tag): ?>
                            <li><?= e($tag) ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>

                <div class="record-side mt-4">
                    <h2 class="record-heading">Research Details</h2>
                    <div class="row">
                        <div class="col-md-4">
                            <small>Major</small>
                            <div><?= e($record['category_name']) ?></div>
                        </div>
                        <div class="col-md-4">
                            <small>Program</small>
                            <div><?= e($record['program_name'] ?? 'BS Information Technology') ?></div>
                        </div>
                        <div class="col-md-4">
                            <small>Year</small>
                            <div><?= e($record['year']) ?></div>
                        </div>
                    </div>
                </div>
            </section>

            <aside class="pdf-panel">
                <h2 class="record-heading">Research Document</h2>

                <?php if ($hasFile): ?>
                    <iframe class="pdf-frame" src="<?= e($documentUrl) ?>#toolbar=1" title="Research PDF"></iframe>
                    <a class="btn btn-outline-secondary w-100 mt-2" href="<?= e($documentUrl) ?>" download>Download PDF</a>
                <?php else: ?>
                    <div class="no-pdf">No PDF has been uploaded for this record.</div>
                <?php endif; ?>
            </aside>
        </div>
    </article>

    <?php if ($related): ?>
        <section class="related">
            <h2>More research in this major</h2>
            <ul class="related-list">
                <?php foreach ($related as $item): ?>
                    <li>
                        <a href="<?= BASE_URL ?>research-details.php?id=<?= (int) $item['research_id'] ?>"><?= e($item['title']) ?></a>
                        <span><?= e($item['year']) ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
        </section>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>