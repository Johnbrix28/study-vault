<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_student();

$total = (int) $pdo->query('SELECT COUNT(*) FROM research')->fetchColumn();

$recent = $pdo->query("
    SELECT
        r.research_id,
        r.title,
        r.year,
        r.published_date,
        r.abstract,
        c.category_name,
        (
            SELECT GROUP_CONCAT(a.full_name ORDER BY a.full_name SEPARATOR ', ')
            FROM research_authors ra
            JOIN authors a ON a.author_id = ra.author_id
            WHERE ra.research_id = r.research_id
        ) researchers
    FROM research r
    JOIN categories c ON c.category_id = r.category_id
    ORDER BY r.published_date DESC, r.research_id DESC
    LIMIT 6
")->fetchAll();

$cats = $pdo->query('
    SELECT
        c.category_id,
        c.category_name,
        COUNT(r.research_id) total
    FROM categories c
    LEFT JOIN research r ON r.category_id = c.category_id
    GROUP BY c.category_id, c.category_name
    ORDER BY c.category_id
')->fetchAll();

$pageTitle = 'Home';
require __DIR__ . '/includes/header.php';
?>

<section class="student-hero">
    <div class="container">
        <div class="hero-copy">
            <h1>Welcome to Study Vault</h1>
            <p>Explore previous thesis and research works to help you discover ideas, references, and related studies for your own research.</p>

            <form class="search-bar live-search-form" action="<?= BASE_URL ?>research.php" method="get" autocomplete="off">
                <div class="suggest-wrap">
                    <input class="form-control live-search" type="search" name="q" placeholder="Search by title, researcher, keyword..." data-suggest-url="<?= BASE_URL ?>suggestions.php">
                    <div class="suggestions" hidden></div>
                </div>
                <button class="btn btn-primary" type="submit">Search</button>
            </form>

            <p class="hero-small"><?= $total ?> research records currently in the repository.</p>
        </div>
    </div>
</section>

<section class="container section">
    <div class="section-head">
        <div>
            <p class="eyebrow">ABOUT THE SYSTEM</p>
            <h2>Study Vault Research Repository</h2>
        </div>
    </div>
    <div class="intro-panel">
        <p>Study Vault is a centralized repository for authorized Information Technology research works from <strong>2022–2025</strong>. Students can search, filter, browse research details, and read available documents directly in the system.</p>
    </div>
</section>

<section class="container section">
    <div class="section-head">
        <h2>Research by Major</h2>
        <a href="<?= BASE_URL ?>research.php">View all</a>
    </div>
    <div class="row g-3">
        <?php foreach ($cats as $c): ?>
            <div class="col-md-6">
                <a class="category-tile major-tile" href="<?= BASE_URL ?>research.php?category=<?= (int) $c['category_id'] ?>">
                    <strong><?= e($c['category_name']) ?></strong>
                    <span><?= ((int) $c['total']) ?> research record<?= ((int) $c['total'] === 1 ? '' : 's') ?></span>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<section class="container section">
    <div class="section-head">
        <h2>Recent Research</h2>
    </div>
    <div class="row g-3">
        <?php foreach ($recent as $r): ?>
            <div class="col-md-6 col-lg-4">
                <article class="research-card">
                    <p class="card-meta"><?= e($r['category_name']) ?> · <?= e($r['year']) ?></p>
                    <h3>
                        <a href="<?= BASE_URL ?>research-details.php?id=<?= (int) $r['research_id'] ?>"><?= e($r['title']) ?></a>
                    </h3>
                    <p class="card-authors"><?= e($r['researchers'] ?? 'Researchers not recorded') ?></p>
                    <p class="card-abstract"><?= e(excerpt($r['abstract'])) ?></p>
                    <a class="card-link" href="<?= BASE_URL ?>research-details.php?id=<?= (int) $r['research_id'] ?>">View details →</a>
                </article>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>