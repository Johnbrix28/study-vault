# Study Vault: Thesis and Research System

A working PHP 8 + MySQL repository of previous thesis and research works, built for
XAMPP. Students search and browse without an account; library personnel sign in to a
protected administrator area to manage records.

---

## 1. Setup (about five minutes)

1. Copy the `study-vault` folder into your XAMPP web root:
   - Windows: `C:\xampp\htdocs\study-vault`
   - macOS: `/Applications/XAMPP/htdocs/study-vault`
2. Start **Apache** and **MySQL** in the XAMPP control panel.
3. Open <http://localhost/phpmyadmin>, go to **Import**, choose
   `database/study_vault.sql` and run it. This creates the `study_vault` database,
   all tables, and the sample data.
4. Open <http://localhost/study-vault/>.

If your MySQL root account has a password, or you renamed the folder, edit
`config/database.php` — everything is defined at the top of that one file.

### Development admin account

| Username | Password | Notes |
|---|---|---|
| `admin` | `admin123` | Development/test account only |
| `librarian` | `admin123` | Second test account |

Passwords are stored as bcrypt hashes produced by `password_hash()`. Change them
before the system is used for real: open `database/make-password-hash.php`, generate
a new hash, update the row in phpMyAdmin, then delete that helper file.

---

## 2. What works

**Public side**
- Homepage with live counts, recently added records and category tiles
- Search across title, abstract, keywords, category, program and author name
- Filters for year, category and program, combinable, plus sorting and pagination
- Result count and a clear-filters path; a real empty state when nothing matches
- Record detail page loaded by validated ID, with related records
- PDF open/download when a document is attached

**Administrator side**
- Sign-in with `password_verify()`, session regeneration, 30-minute idle timeout
- Dashboard figures counted from the database, never hard-coded
- Research create, read, update, delete with a confirmation step before deleting
- Categories, programs and authors management, with delete blocked while a record
  still depends on them
- Many-to-many authors: pick existing authors, or type new names that are reused
  rather than duplicated
- Activity log of sign-ins, sign-outs and every add/edit/delete, with filtering

**Security**
- PDO prepared statements everywhere; no user input is concatenated into SQL
- All output escaped with `htmlspecialchars()` through the `e()` helper
- CSRF tokens on every state-changing form
- Every admin page calls `require_admin()` on its first lines, so visiting
  `/admin/dashboard.php` while signed out redirects to the login page
- Uploads: PDF extension and MIME check, 10 MB cap, random filename, stored outside
  the code path with an `.htaccess` that disables script execution
- Raw PHP/MySQL errors are logged, never shown; users see plain-language messages

---

## 3. Folder map

```
study-vault/
├── index.php              Homepage / repository
├── research.php           Browse, search, filter
├── research-details.php   Single record
├── login.php              Redirects to the admin login
├── logout.php
├── admin/
│   ├── login.php  logout.php  dashboard.php
│   ├── research.php  research-add.php  research-edit.php  research-delete.php
│   ├── categories.php  programs.php  authors.php  activity-logs.php
├── config/
│   ├── database.php       Credentials, BASE_URL, upload limits, DEV_MODE
│   └── session.php
├── includes/
│   ├── bootstrap.php      One include that loads the four files below
│   ├── auth.php  functions.php
│   ├── header.php  footer.php
│   ├── admin-header.php  admin-footer.php
│   └── research-form.php  Shared add/edit form
├── assets/
│   ├── css/style.css  js/script.js
│   ├── images/        Swap the logos here
│   └── uploads/       Uploaded PDFs (+ .htaccess)
└── database/
    ├── study_vault.sql
    └── make-password-hash.php   Delete before handing over
```

---

## 4. Changing the look

The visual design is deliberately kept separate from the logic:

- **Colours, fonts, radii** — the `:root` block at the top of `assets/css/style.css`.
  Change those tokens and the whole system follows.
- **Logos** — drop `study-vault-logo.png` and `isu-logo.png` into `assets/images/`.
  The current files are neutral placeholders. If an image is missing the header
  hides it instead of breaking.
- **Header, footer, navigation** — `includes/header.php`, `includes/footer.php`,
  `includes/admin-header.php`. Every page uses them, so one edit is enough.
- **Site name and tagline** — `config/database.php`.

Do not add an institutional logo or claim affiliation without your team's
permission to use it.

---

## 5. Sample data

The eight research records loaded by the SQL file are **fictional** and exist only to
test search, filtering and the admin tools. Each abstract is prefixed with
`[SAMPLE RECORD - DEVELOPMENT DATA ONLY]`. Delete them from
**Admin → Research records** once authorised records are available.

---

## 6. Test checklist

Public: homepage loads · navigation works · search returns matching records ·
year, category and program filters work alone and together · author name search works ·
detail page opens the right record · an invalid or missing `id` redirects with a message ·
PDF opens and downloads · layout holds at 360 px, 768 px and 1280 px.

Admin: login succeeds with the correct password · a wrong password is rejected with
"Invalid username or password." · dashboard figures match the record counts ·
add, edit and delete research · delete asks for confirmation first · categories,
programs and authors CRUD · deleting an in-use category is refused · activity log
records each action · logout ends the session · opening `/admin/dashboard.php` after
logout redirects to the login page.

Uploads: a non-PDF is rejected · a file over 10 MB is rejected · a valid PDF appears on
the public record page · deleting a record also deletes its file.

---

## 7. Before handing in

- [ ] Change the `admin` and `librarian` passwords
- [ ] Delete `database/make-password-hash.php`
- [ ] Set `DEV_MODE` to `false` in `config/database.php`
- [ ] Replace the sample research records
- [ ] Replace the placeholder logos
