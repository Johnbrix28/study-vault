<?php

/* ============================================================
   Output helpers
   ============================================================ */
function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

/* ============================================================
   Flash messages
   ============================================================ */
function set_flash(string $type, string $message): void
{
    $_SESSION['flash'][] = [
        'type'    => $type,
        'message' => $message,
    ];
}

function get_flashes(): array
{
    $x = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $x;
}

function render_flashes(): void
{
    foreach (get_flashes() as $f) {
        printf(
            '<div class="alert alert-%s alert-dismissible fade show" role="alert">%s<button type="button" class="btn-close" data-bs-dismiss="alert" data-bs-dismiss="alert" aria-label="Close"></button></div>',
            e($f['type']),
            e($f['message'])
        );
    }
}

/* ============================================================
   CSRF protection
   ============================================================ */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function csrf_valid(): bool
{
    return isset($_POST['csrf_token'])
        && is_string($_POST['csrf_token'])
        && hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token']);
}

/* ============================================================
   Input sanitizing
   ============================================================ */
function valid_id($v)
{
    return filter_var($v, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
}

function clean_text($v): string
{
    return trim(preg_replace('/\s+/u', ' ', (string) $v));
}

/* ============================================================
   Activity logging
   ============================================================ */
function log_activity(PDO $pdo, string $action): void
{
    try {
        $s = $pdo->prepare('INSERT INTO activity_logs(admin_id,action) VALUES(?,?)');
        $s->execute([$_SESSION['admin_id'] ?? null, mb_substr($action, 0, 255)]);
    } catch (PDOException $e) {
        error_log($e->getMessage());
    }
}

/* ============================================================
   Lookup helpers
   ============================================================ */
function get_categories(PDO $pdo): array
{
    return $pdo->query('SELECT * FROM categories ORDER BY category_id')->fetchAll();
}

function get_programs(PDO $pdo): array
{
    return $pdo->query('SELECT * FROM programs ORDER BY program_name')->fetchAll();
}

function get_research_years(PDO $pdo): array
{
    return $pdo->query('SELECT DISTINCT year FROM research ORDER BY year DESC')->fetchAll(PDO::FETCH_COLUMN);
}

function keyword_list(?string $k): array
{
    return $k
        ? array_values(array_filter(array_map('trim', explode(',', $k)), 'strlen'))
        : [];
}

/* ============================================================
   Formatting helpers
   ============================================================ */
function excerpt(?string $t, int $len = 180): string
{
    $t = trim((string) $t);

    if ($t === '') {
        return 'No abstract recorded.';
    }

    return mb_strlen($t) <= $len
        ? $t
        : rtrim(mb_substr($t, 0, $len), ' ,.;:-') . '...';
}

function format_date(?string $v): string
{
    return $v ? date('M j, Y', strtotime($v)) : '--';
}

function format_datetime(?string $v): string
{
    return $v ? date('M j, Y g:i A', strtotime($v)) : '--';
}

/* ============================================================
   File handling
   ============================================================ */
function research_file_exists(?string $p): bool
{
    return $p && is_file(BASE_PATH . '/' . ltrim($p, '/'));
}

function delete_research_file(?string $p): void
{
    if (!$p) {
        return;
    }

    $full = BASE_PATH . '/' . ltrim($p, '/');

    if (
        is_file($full)
        && strpos((string) realpath($full), (string) realpath(UPLOAD_DIR)) === 0
    ) {
        @unlink($full);
    }
}

function handle_pdf_upload(array $file, ?string &$error)
{
    if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    if ($file['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) {
        $error = 'The PDF could not be uploaded.';
        return false;
    }

    if ($file['size'] > MAX_UPLOAD_BYTES) {
        $error = 'The PDF exceeds the ' . (MAX_UPLOAD_BYTES / 1048576) . ' MB limit.';
        return false;
    }

    if (strtolower(pathinfo($file['name'], PATHINFO_EXTENSION)) !== 'pdf') {
        $error = 'Only PDF files are allowed.';
        return false;
    }

    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);

    if (!in_array($mime, ['application/pdf', 'application/x-pdf'], true)) {
        $error = 'The uploaded file is not a valid PDF.';
        return false;
    }

    if (!is_dir(UPLOAD_DIR) && !mkdir(UPLOAD_DIR, 0755, true)) {
        $error = 'Upload folder could not be created.';
        return false;
    }

    $name = 'research-' . date('Ymd') . '-' . bin2hex(random_bytes(8)) . '.pdf';

    if (!move_uploaded_file($file['tmp_name'], UPLOAD_DIR . $name)) {
        $error = 'The PDF could not be saved.';
        return false;
    }

    @chmod(UPLOAD_DIR . $name, 0644);

    return 'assets/uploads/' . $name;
}

/* ============================================================
   Author helpers
   ============================================================ */
function get_research_authors(PDO $pdo, int $id): array
{
    $s = $pdo->prepare('SELECT a.full_name FROM research_authors ra JOIN authors a ON a.author_id=ra.author_id WHERE ra.research_id=? ORDER BY a.full_name');
    $s->execute([$id]);
    return $s->fetchAll(PDO::FETCH_COLUMN);
}

function find_or_create_author(PDO $pdo, string $name): int
{
    $name = clean_text($name);

    $s = $pdo->prepare('SELECT author_id FROM authors WHERE full_name=? LIMIT 1');
    $s->execute([$name]);
    $id = $s->fetchColumn();

    if ($id) {
        return (int) $id;
    }

    $s = $pdo->prepare('INSERT INTO authors(full_name) VALUES(?)');
    $s->execute([$name]);

    return (int) $pdo->lastInsertId();
}

function sync_researchers(PDO $pdo, int $researchId, string $names): void
{
    $pdo->prepare('DELETE FROM research_authors WHERE research_id=?')->execute([$researchId]);

    foreach (array_filter(array_map('clean_text', explode(',', $names))) as $name) {
        $aid = find_or_create_author($pdo, $name);
        $s = $pdo->prepare('INSERT INTO research_authors(research_id,author_id) VALUES(?,?)');
        $s->execute([$researchId, $aid]);
    }
}