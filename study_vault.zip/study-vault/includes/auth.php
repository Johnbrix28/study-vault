<?php

/* ============================================================
   Auth state checks
   ============================================================ */
function is_logged_in(): bool
{
    return !empty($_SESSION['admin_id']);
}

function is_student_logged_in(): bool
{
    return !empty($_SESSION['student_id']);
}

/* ============================================================
   Current user accessors
   ============================================================ */
function current_admin(): array
{
    return [
        'admin_id' => $_SESSION['admin_id'] ?? null,
        'name'     => $_SESSION['admin_name'] ?? '',
        'username' => $_SESSION['admin_username'] ?? '',
        'role'     => $_SESSION['admin_role'] ?? '',
    ];
}

function current_student(): array
{
    return [
        'student_id'     => $_SESSION['student_id'] ?? null,
        'student_number' => $_SESSION['student_number'] ?? '',
        'name'           => $_SESSION['student_name'] ?? '',
    ];
}

/* ============================================================
   Login handlers
   ============================================================ */
function login_admin(array $a): void
{
    session_regenerate_id(true);

    $_SESSION['admin_id']       = (int) $a['admin_id'];
    $_SESSION['admin_name']     = $a['name'];
    $_SESSION['admin_username'] = $a['username'];
    $_SESSION['admin_role']     = $a['role'];
    $_SESSION['last_activity']  = time();
}

function login_student(array $s): void
{
    session_regenerate_id(true);

    $_SESSION['student_id']            = (int) $s['student_id'];
    $_SESSION['student_number']        = $s['student_number'];
    $_SESSION['student_name']          = $s['first_name'] . ' ' . $s['last_name'];
    $_SESSION['student_last_activity'] = time();
}

/* ============================================================
   Logout handlers
   ============================================================ */
function logout_admin(): void
{
    foreach (['admin_id', 'admin_name', 'admin_username', 'admin_role', 'last_activity'] as $k) {
        unset($_SESSION[$k]);
    }
}

function logout_student(): void
{
    foreach (['student_id', 'student_number', 'student_name', 'student_last_activity'] as $k) {
        unset($_SESSION[$k]);
    }
}

/* ============================================================
   Route guards
   ============================================================ */
function require_admin(): void
{
    if (!is_logged_in()) {
        set_flash('warning', 'Sign in as administrator to continue.');
        redirect(BASE_URL . 'admin/login.php');
    }

    if (isset($_SESSION['last_activity']) && time() - $_SESSION['last_activity'] > ADMIN_IDLE_TIMEOUT) {
        logout_admin();
        set_flash('warning', 'Your administrator session expired. Please sign in again.');
        redirect(BASE_URL . 'admin/login.php');
    }

    $_SESSION['last_activity'] = time();
}

function require_student(): void
{
    if (!is_student_logged_in()) {
        set_flash('warning', 'Please sign in as a student to access Study Vault.');
        redirect(BASE_URL . 'login.php');
    }

    $_SESSION['student_last_activity'] = time();
}