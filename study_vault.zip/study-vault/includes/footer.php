    </main>

    <footer class="site-footer">
        <div class="container">
            <div class="footer-brand">Study Vault</div>
            <p class="footer-note">A thesis and research repository for Information Technology students. Research records are maintained by authorized library personnel.</p>
            <p class="footer-legal">&copy; <?= date('Y') ?> Study Vault. Academic project build.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?= BASE_URL ?>assets/js/script.js"></script>
</body>

</html>