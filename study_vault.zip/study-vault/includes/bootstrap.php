<?php
/**
 * Single entry point for every page: database, session, helpers, auth.
 * Public pages:  require_once __DIR__ . '/includes/bootstrap.php';
 * Admin pages:   require_once __DIR__ . '/../includes/bootstrap.php';
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';
