<?php
$pageTitle = $pageTitle ?? 'Administrator';
$currentNav = basename($_SERVER['PHP_SELF']);
$admin = current_admin();

$sidebarGroups = [
    [
        'label' => 'Overview',
        'items' => [
            'dashboard.php' => 'Dashboard',
        ],
    ],
    [
        'label' => 'Research',
        'items' => [
            'research-database.php' => 'Research Database',
            'research-add.php'      => 'Add Research',
        ],
    ],
    [
        'label' => 'Management',
        'items' => [
            'students.php'      => 'Students',
            'categories.php'    => 'Category Display',
            'activity-logs.php' => 'Activity Logs',
        ],
    ],
];
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?= e($pageTitle) ?> &middot; Study Vault Admin</title>
    <link rel="icon" href="<?= BASE_URL ?>assets/images/study-vault-logo.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= BASE_URL ?>assets/css/style.css" rel="stylesheet">
</head>

<body class="admin-body">
    <nav class="admin-topbar">
        <div>
            <button class="btn btn-sm btn-menu d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#adminSidebar">&#9776;</button>
            <a class="admin-brand" href="<?= BASE_URL ?>admin/dashboard.php"><img src="<?= BASE_URL ?>assets/images/isu-logo.png" alt="Study Vault" class="admin-brand-mark" style="width:28px;height:28px;object-fit:contain;"><span class="admin-brand-name">Study Vault</span></a>
        </div>
        <div class="d-flex align-items-center gap-2">
            <span class="admin-who d-none d-md-inline">Hi, Administrator</span>
            <a class="btn btn-sm btn-ghost" href="<?= BASE_URL ?>index.php">Student Site</a>
            <a class="btn btn-sm btn-ghost" href="<?= BASE_URL ?>admin/logout.php">Logout</a>
        </div>
    </nav>

    <div class="admin-shell">
        <aside class="offcanvas-lg offcanvas-start admin-sidebar" tabindex="-1" id="adminSidebar">
            <div class="offcanvas-header">
                <h2 class="h6">Admin Menu</h2>
                <button class="btn-close" data-bs-dismiss="offcanvas"></button>
            </div>
            <div class="offcanvas-body">
                <ul class="admin-menu">
                    <?php foreach ($sidebarGroups as $group): ?>
                        <li class="admin-menu-group">
                            <span class="admin-menu-label"><?= e($group['label']) ?></span>
                            <ul class="admin-menu-sub">
                                <?php foreach ($group['items'] as $file => $label): ?>
                                    <?php $active = $currentNav === $file; ?>
                                    <li>
                                        <a class="<?= $active ? 'active' : '' ?>" href="<?= BASE_URL ?>admin/<?= e($file) ?>"><?= e($label) ?></a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </aside>

        <main class="admin-main" id="admin-main">
            <?php render_flashes(); ?>