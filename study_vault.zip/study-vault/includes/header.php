<?php
$pageTitle = $pageTitle ?? SITE_NAME;
$currentNav = basename($_SERVER['PHP_SELF']);
$student = current_student();
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?= e($pageTitle) ?> &middot; <?= e(SITE_NAME) ?></title>
    <link rel="icon" href="<?= BASE_URL ?>assets/images/study-vault-logo.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= BASE_URL ?>assets/css/style.css" rel="stylesheet">
</head>

<body class="student-body">
    <a class="skip-link" href="#main">Skip to content</a>

    <header class="site-header">
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="<?= BASE_URL ?>index.php">
                    <img src="<?= BASE_URL ?>assets/images/isu-logo.png" alt="Study Vault" class="brand-mark">
                    <span class="brand-text">
                        <strong>Study Vault</strong>
                        <small>Thesis and Research System</small>
                    </span>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="mainNav">
                    <ul class="navbar-nav ms-auto align-items-lg-center">
                        <li class="nav-item">
                            <a class="nav-link <?= $currentNav === 'index.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= $currentNav === 'research.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>research.php">Search Research</a>
                        </li>
                        <li class="nav-item ms-lg-3">
                            <?php if (is_student_logged_in()): ?>
                                <span class="student-welcome">Hi, <?= e($student['name']) ?></span>
                                <a class="btn btn-outline-light btn-sm ms-2" href="<?= BASE_URL ?>logout.php">Logout</a>
                            <?php else: ?>
                                <a class="btn btn-outline-light btn-sm" href="<?= BASE_URL ?>login.php">Student Login</a>
                            <?php endif; ?>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main id="main">
        <div class="container flash-area">
            <?php render_flashes(); ?>
        </div>