<?php
require_once __DIR__ . '/includes/bootstrap.php';

if (is_student_logged_in()) {
    redirect(BASE_URL . 'index.php');
}

$error = '';
$form = [
    'student_number' => '',
    'first_name'     => '',
    'last_name'      => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        $error = 'Your session expired. Please try again.';
    } else {
        foreach ($form as $k => $_) {
            $form[$k] = clean_text($_POST[$k] ?? '');
        }

        $password = (string) ($_POST['password'] ?? '');
        $confirm  = (string) ($_POST['confirm_password'] ?? '');

        if (in_array('', $form, true) || $password === '' || $confirm === '') {
            $error = 'Complete all required fields.';
        } elseif (!preg_match('/^[A-Za-z0-9._-]{3,50}$/', $form['student_number'])) {
            $error = 'Enter a valid Student ID number.';
        } elseif (strlen($password) < 6) {
            $error = 'Password must be at least 6 characters.';
        } elseif ($password !== $confirm) {
            $error = 'Passwords do not match.';
        } else {
            $s = $pdo->prepare('SELECT student_id FROM students WHERE student_number=?');
            $s->execute([$form['student_number']]);

            if ($s->fetch()) {
                $error = 'That Student ID is already registered.';
            } else {
                $s = $pdo->prepare('INSERT INTO students(student_number,first_name,last_name,password) VALUES(?,?,?,?)');
                $s->execute([
                    $form['student_number'],
                    $form['first_name'],
                    $form['last_name'],
                    password_hash($password, PASSWORD_DEFAULT),
                ]);
                set_flash('success', 'Account created successfully. Please log in.');
                redirect(BASE_URL . 'login.php');
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Create Student Account &middot; Study Vault</title>
    <link rel="icon" href="<?= BASE_URL ?>assets/images/study-vault-logo.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= BASE_URL ?>assets/css/style.css" rel="stylesheet">
</head>

<body class="auth-page">
    <div class="auth-overlay">
        <div class="auth-card">
            <div class="login-brand">
                <img src="<?= BASE_URL ?>assets/images/isu-logo.png" alt="Study Vault">
                <div>
                    <strong>Study Vault</strong>
                    <span>Thesis and Research System</span>
                </div>
            </div>

            <p class="eyebrow">STUDENT REGISTRATION</p>
            <h1>Create Account</h1>
            <p class="login-sub">Create your student account to access the research repository.</p>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= e($error) ?></div>
            <?php endif; ?>

            <form method="post" data-validate>
                <?= csrf_field() ?>

                <div class="mb-3">
                    <label class="form-label">Student ID Number</label>
                    <input class="form-control" name="student_number" required value="<?= e($form['student_number']) ?>">
                </div>

                <div class="row g-2">
                    <div class="col-sm-6 mb-3">
                        <label class="form-label">First Name</label>
                        <input class="form-control" name="first_name" required value="<?= e($form['first_name']) ?>">
                    </div>
                    <div class="col-sm-6 mb-3">
                        <label class="form-label">Last Name</label>
                        <input class="form-control" name="last_name" required value="<?= e($form['last_name']) ?>">
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input class="form-control" type="password" name="password" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Confirm Password</label>
                    <input class="form-control" type="password" name="confirm_password" required>
                </div>

                <button class="btn btn-primary w-100" type="submit">Create Account</button>
            </form>

            <p class="auth-switch">Already have an account? <a href="<?= BASE_URL ?>login.php">Login</a></p>
        </div>
    </div>
</body>

</html>