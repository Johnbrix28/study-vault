<?php
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']),
    ]);
    session_name('STUDYVAULTSESSID');
    session_start();
}
if (!defined('ADMIN_IDLE_TIMEOUT')) define('ADMIN_IDLE_TIMEOUT', 1800);
