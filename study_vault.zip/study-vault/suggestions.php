<?php
require_once __DIR__ . '/includes/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

$query = clean_text($_GET['q'] ?? '');
if (mb_strlen($query) < 2) {
    echo json_encode([]);
    exit;
}

$like = '%' . $query . '%';
$stmt = $pdo->prepare(
    "SELECT DISTINCT suggestion
       FROM (
            SELECT r.title AS suggestion
              FROM research r
             WHERE r.title LIKE :title

            UNION

            SELECT a.full_name AS suggestion
              FROM authors a
              JOIN research_authors ra ON ra.author_id = a.author_id
             WHERE a.full_name LIKE :author

            UNION

            SELECT c.category_name AS suggestion
              FROM categories c
             WHERE c.category_name LIKE :category

            UNION

            SELECT r.keywords AS suggestion
              FROM research r
             WHERE r.keywords LIKE :keywords
       ) suggestions
      WHERE suggestion IS NOT NULL AND suggestion <> ''
      ORDER BY suggestion
      LIMIT 8"
);
$stmt->execute([
    ':title' => $like,
    ':author' => $like,
    ':category' => $like,
    ':keywords' => $like,
]);

$suggestions = [];
foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $value) {
    foreach (keyword_list($value) as $keyword) {
        if (stripos($keyword, $query) !== false) {
            $suggestions[] = $keyword;
        }
    }
}

$suggestions = array_values(array_unique($suggestions));
echo json_encode(array_slice($suggestions, 0, 8), JSON_UNESCAPED_UNICODE);
